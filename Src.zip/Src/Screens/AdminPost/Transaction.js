export default [
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
  {
    Username: 'Aslam Khan',

    Email: 'sp',
    Phone: +9244456433,
    type: 'Credit',
    owner: 'Hostel Owner',
  },
];
